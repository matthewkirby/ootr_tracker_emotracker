CHANGELOG

v1.1.0
- Master Quest keys counts are now supported and can be toggled on/off by clicking dungeon names
- Badge on bomb bag to indicate logical bomchus in extended and extended+keysanity layouts
- Renamed `pocket_egg.png` to `blue_egg.png`, `weird_egg.png` to `white_egg.png` to avoid confusion when the images are used for both child and adult sequences
- Added `white_chicken.png`
- Added `goron_tunic`, `zora_tunic`, and `composite_tunic` icons for users who wish to override.


Todo List
- Kokiri Sword
- Badge on ocarina to indicate scarecrow song in extended and extended+keysanity layouts