CHANGELOG

v1.0.5
- Renamed `pocket_egg.png` to `blue_egg.png`, `weird_egg.png` to `white_egg.png` to avoid confusion when the images are used for both child and adult sequences
- Added `white_chicken.png`






Wishlist
- MQ Keys
- Badge on bomb bag to indicate logical bomchus in extended and extended+keysanity layouts
- Badge on ocarina to indicate scarecrow song in extended and extended+keysanity layouts