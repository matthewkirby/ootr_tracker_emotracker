-- Thanks Hamsda for support!

dungeons = {
  "forest",
  "fire",
  "water",
  "spirit",
  "shadow",
  "well",
  "fortress",
  "gtg",
  "ganon"
}
key_counts = {
  vanilla = {
    forest = 5,
    fire = 8,
    water = 6,
    spirit = 5,
    shadow = 5,
    well = 3,
    fortress = 1,
    gtg = 9,
    ganon = 2,
  },
  mq = {
    forest = 6,
    fire = 5,
    water = 2,
    spirit = 7,
    shadow = 6,
    well = 2,
    fortress = 4,
    gtg = 3,
    ganon = 3,
  }
}

function has(item, amount)
  local count = Tracker:ProviderCountForCode(item)
  amount = tonumber(amount)
  if not amount then
    return count > 0
  else
    return count == amount
  end
end

function update_smallkeys()
  for _,dungeon in ipairs(dungeons) do
    local key_object = Tracker:FindObjectForCode(dungeon.."_sk")
    if key_object then
      if has(dungeon.."_name_normal",1) then
        key_object.MaxCount = key_counts["vanilla"][dungeon]
      else
        key_object.MaxCount = key_counts["mq"][dungeon]
      end
    end
  end
end

function tracker_on_accessibility_updated()
  update_smallkeys()
end
