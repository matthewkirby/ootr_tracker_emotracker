CHANGELOG

v1.2.0
- Replaced Gerudo Card tracker with a composite Kokiri Sword/Gerudo Card tracker (Extended layouts only)
- Replaced ice trap counter with the a composite Goron/Zora tunic tracker (Extended layouts only)
- Added a badge (right click) on the Ocarina item to mark Scarecrow Song (Extended layouts only)
- Default Gerudo Fortress max keys is now set to 1. Toggling the name to red changes max keys to 4. (Keysanity layouts only)
- Added damage multiplier item object. This will be integrated into a new layout shortly but is available for override now.

v1.1.1
- Fixed version bug in manifest 

v1.1.0
- Master Quest keys counts are now supported and can be toggled on/off by clicking dungeon names
- Badge on bomb bag to indicate logical bomchus in extended and extended+keysanity layouts
- Renamed `pocket_egg.png` to `blue_egg.png`, `weird_egg.png` to `white_egg.png` to avoid confusion when the images are used for both child and adult sequences
- Added `white_chicken.png`
- Added `goron_tunic`, `zora_tunic`, and `composite_tunic` icons for users who wish to override.

Todo List
- New layout that is extended+keysanity with a settings section below it. Broadcast view for this version will be the settings. I can crop away the settings stuff on obs