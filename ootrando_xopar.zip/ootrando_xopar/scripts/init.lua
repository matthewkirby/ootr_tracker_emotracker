-- Load the items
Tracker:AddItems("items/dungeon_rewards.json")
Tracker:AddItems("items/dungeon_items.json")
Tracker:AddItems("items/magic_items.json")
Tracker:AddItems("items/misc_items.json")
Tracker:AddItems("items/trade_items.json")
Tracker:AddItems("items/songs.json")
Tracker:AddItems("items/misc.json")
Tracker:AddItems("items/composite_items.json")
Tracker:AddItems("items/keysanity.json")

-- Load the grids
Tracker:AddLayouts("layouts/medallion_grid.json")
Tracker:AddLayouts("layouts/song_grid.json")
Tracker:AddLayouts("layouts/item_grids.json")
Tracker:AddLayouts("layouts/key_grid.json")

-- Load the tracker and broadcast layouts
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")